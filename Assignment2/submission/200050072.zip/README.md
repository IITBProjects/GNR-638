# Setup
To setup the virtual environment run the following command 
```
python3 setup_env.py
```

To compare the gradients and store them as a json file run the following command
```
python3 run.py 
```
# Overleaf Link
https://www.overleaf.com/read/nhrfchtfpcxm#71120f