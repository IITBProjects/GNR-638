# Setup
To setup the virtual environment run the following command 
```
python3 setup_env.py
```

To run task 1 run the following command 
```
python3 run.py --task 1
```
To run task 2 run the following command 
```
python3 run.py --task 2
```
# Google Doc Link
https://docs.google.com/document/d/1FU28_niDoqE4keBysePofnEHzdZPG9m3EtHQMjt8LZM/edit?usp=sharing

# References
https://github.com/gurkandemir/Bag-of-Visual-Words/tree/master