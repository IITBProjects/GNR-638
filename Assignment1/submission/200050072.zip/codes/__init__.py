from . import BoW
from .import BoW_with_glcm
from . import plotter

from .BoW import trainModel,testModel
from .BoW_with_glcm import trainModelWithGLCM,testModelWithGLCM
from .plotter import varyKAndPlot
